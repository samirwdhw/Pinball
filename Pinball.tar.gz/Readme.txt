PINBALL GAME
==============

CREDITS

Aditya Kumar Akash (Mentor for project)
Mrs. Varsha Apte 

Samir Wadhwa (150100024)
Anish Ram Senathi (150100023)

OVERVIEW

This is a pinball game which allows the user to create the course
It provides points and key input to move the bat
All obstacles, bats, launchers are created as objects 
Obstacles are coded in a general way to be positioned anywhere(So that entries are taken by user)

INSTRUCTIONS

1. The uses of respective buttons are given in the program
2. Go to the terminal to choose to make a course or use a default course made by the coders
3. To pause the game press 'p' and any other button to continue
4. Any event(click, keypress, etc) can be used to terminate code after game over

